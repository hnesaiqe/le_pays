index
<?php get_header(); ?>
<div class="row text-center d-flex align-items-center border border-light">
    <div class="content col-7 bg-warning border border-light">
        <h1>CONTENT</h1>
    </div>
    <div class="slideBar col-5 bg-dark border border-light">
        <h1>SideBar</h1>
    </div>
</div>
<?php get_footer(); ?>