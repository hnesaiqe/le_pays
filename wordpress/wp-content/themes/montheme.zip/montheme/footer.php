<?php wp_footer(); ?>
<!-- Vous pourriez ajouter votre script Google Analytics ici -->

        <div class="row justify-content-center border border-light text-success text-center text-dark" style="background-color: #00a7e3;">
            <footer>
                <div class="footer row">
                    <div class="col">
                        <h6>©Copyright. All right reserved. HNE Saiqë</h6>
                    </div>
                </div>
            </footer>
        </div>
        </body>
    </div>
    
</html>